# Chạy bộ công cụ dựng

Các script là bộ dựng FFmpeg dùng lại từ các bản đã làm cho kênh, không cần CapCut hoặc một skill khác. Có thể dựng thủ công với cùng nhận diện và tiêu chí nghiệm thu trong SKILL.md.

## Môi trường

Python 3.11/3.12, FFmpeg và ffprobe có libass, libx264, AAC và minterpolate. Tạo virtualenv, cài `requirements.txt` bằng pip. ASR/căn lời tải mô hình tiếng Việt ở lần chạy đầu; bước render/QA không cần tải mô hình. Có thể dùng môi trường đã có đủ thư viện, không cài lại không cần thiết.

Font mặc định là Helvetica Neue trên macOS. Nền tảng khác cấu hình `font`, `font_family`, `title_font_index`, `subtitle_font_index` và đo lại chữ. Với file TTF một mặt thường index=0. Font được cấp phép sử dụng phải có đủ dấu Việt; gói không sao chép font hệ thống.

Đặt `S` là thư mục skill, `W` là thư mục riêng của video. Các lệnh dưới đây minh họa tham số, không chứa đường dẫn cá nhân:

```bash
python "$S/scripts/transcribe.py" "$W/voice.mp3" "$W/asr.json"
python "$S/scripts/align.py" "$W/voice.mp3" "$W/script.txt" "$W/words.json"
python "$S/scripts/render.py" "$W/project.json" --check
python "$S/scripts/render.py" "$W/project.json"
python "$S/scripts/qa_export.py" "$W"
```

`transcribe.py` tạo bản nháp. Đọc lại và lưu `script.txt` đã sửa trước khi align. Cú pháp tên/số: `PNJ{pi_en_giây}`, `5,5{năm_triệu_năm_trăm_nghìn}` nếu đúng âm thanh. Đừng tự thêm chữ để ép dữ kiện.

## Manifest dựng

Tạo `project.json` trong `W`. Đây là cấu trúc minh họa, **mốc thời gian và câu phải thay theo MP3 thật**:

```json
{
  "audio": "voice.mp3",
  "alignment": "words.json",
  "output": "video.mp4",
  "title_lines": ["THƯƠNG HIỆU", "VÀ THAY ĐỔI CỤ THỂ"],
  "title_size": 66,
  "title_line_step": 78,
  "title_font_index": 4,
  "subtitle_size": 41,
  "subtitle_font_index": 1,
  "music": {
    "start_seconds": 48.08,
    "gain_db": -20
  },
  "caption_ranges": [[10, 15], [15, 20], [20, 25]],
  "shots": [
    {"name": "Hook", "file": "clips/hook.mp4", "ss": 3.5, "n": 135, "kind": "hook"},
    {"name": "Câu tiếp", "file": "clips/body.mp4", "ss": 10, "n": 150},
    {"name": "Câu cuối", "file": "graphic.png", "ss": 0, "n": 120, "still": true, "zoom": 0.015}
  ]
}
```

- Mọi đường dẫn tương đối trong manifest tính từ thư mục chứa manifest. Công cụ không lấy khóa API hoặc tài khoản từ máy.
- `n`: số frame của cảnh ở 30 fps; tổng frame phải khớp thời lượng voice trong sai số làm tròn. Cảnh đầu là toàn hook, `kind=hook`; các cảnh sau là thân. Cắt sau dấu chấm trong khoảng nghỉ theo words.json. Có thể giữ nhiều câu một cảnh.
- `caption_ranges`: cặp chỉ số `[đầu, cuối)` trong `words.json`, từ đầu thân đến hết lời, liên tục không trùng/thiếu. Không có cue trong hook. Chia bằng cách đọc nghĩa, không chỉ theo số lượng từ.
- `ss`: giây bắt đầu clip gốc. Mặc định lấy dài đúng `n/30`; `srcdur` cho phép lấy góc liên tục ngắn hơn và giảm tốc. Kiểm chuyển động tự nhiên và điểm cắt có sẵn bằng mắt. `interpolation` mặc định `blend`.
- `crop`: tùy chọn `width:height:x:y` để bỏ lề/banner đóng sẵn. Chiều cao thân tính theo tỷ lệ ảnh thật sau crop, scale toàn bộ chiều ngang 1080; nếu đặt `height` thì phải giữ tỷ lệ.
- Hook có thể chỉnh `x`, `y` (biểu thức crop FFmpeg) và `zoom_height` (mặc định 1016) để chủ thể không bị cắt. Xem trước hình thật.
- `still`: ảnh tĩnh, có thể dùng `zoom` nhẹ cho thân. Đây là phương án phụ, không thay việc tìm clip đúng đối tượng.
- `music.path`: tùy chọn. Bỏ trường này để dùng file `assets/nhac-nen-blockbuster-trailer.m4a` đã kèm trong skill. Nếu chỉ định thì đường dẫn tương đối tính từ thư mục manifest. Nếu video vượt phần nhạc còn lại, thêm `loop_end_seconds` là điểm kết đoạn đã chọn theo nhịp và nghe kiểm mối nối.
- Nhạc mặc định gain −20 dB. Nếu chủ kênh yêu cầu khác, sửa đúng thông số và điều kiện đo tương ứng, ghi rõ thay đổi. Không giảm cả mix xuống −20 dB.

## Đầu ra và kiểm tra

Renderer lưu overlay, ASS/SRT, từng cảnh, `plan.json`, âm thanh tham chiếu và MP4 trong `W`. Mỗi lần render dựng lại các cảnh để thay đổi không bị cache cũ. Nó chuẩn hóa giọng hai lượt và trộn nhạc đúng gain.

QA đọc `plan.json`, kiểm thông số, cuts sau câu, bounding box chữ, đo karaoke trên cả libass và bản MP4 nén, đo gain mix và độ lệch voice. Nó tạo `qa-report.json`, `qa-every-second.jpg`, `qa-boundary-and-layout.jpg`.

Xem `unplanned_picture_change_candidates`: có thể là chuyển động lớn chứ không hẳn cắt, và một số dissolve có thể không bị bắt. Bắt buộc xem chuyển động nguồn và bản xuất ở các ranh giới; không coi danh sách rỗng là bằng chứng duy nhất.

QA không xác minh tin tức, giấy phép tư liệu, ý nghĩa phụ đề hoặc việc chủ thể nằm đúng safe area. Các phần đó phải được biên tập kiểm trước khi gửi. Không thay đổi ngưỡng QA chỉ để một bản lỗi được thông qua.
