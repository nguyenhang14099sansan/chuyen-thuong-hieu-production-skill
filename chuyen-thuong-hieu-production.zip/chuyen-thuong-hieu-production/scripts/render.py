from pathlib import Path
import json, math, subprocess, shutil, re
import av
from PIL import Image, ImageDraw, ImageFont

import sys, os
from common import ffmpeg_bin, probe
CONFIG = Path(sys.argv[1]).resolve()
ROOT = CONFIG.parent
CFG = json.loads(CONFIG.read_text(encoding='utf-8'))
def local(path):
    value=Path(path).expanduser()
    return value if value.is_absolute() else ROOT/value
FF = ffmpeg_bin()
ASSETS = Path(__file__).resolve().parent.parent/'assets'
FONT = str(Path(CFG.get('font', '/System/Library/Fonts/HelveticaNeue.ttc')).expanduser())
if not Path(FONT).is_file():
    raise SystemExit('Chỉ định font có đủ dấu Việt trong project.json: font, title_font_index, subtitle_font_index.')
FPS, W, H = 30,1080,1920
shots=CFG['shots']
TOTAL_FRAMES=sum(s['n'] for s in shots)
DURATION=TOTAL_FRAMES/FPS
assert shots and shots[0].get('kind')=='hook'
assert all(s.get('kind')!='hook' for s in shots[1:]), 'Chỉ cảnh đầu dùng khung hook.'
HOOK_END=shots[0]['n']/FPS
audio=local(CFG['audio'])
assert audio.is_file(),audio
voice_duration=float(probe(audio)['format']['duration'])
assert abs(DURATION-voice_duration)<=1/FPS+.02, ('Thời lượng cảnh khác MP3',DURATION,voice_duration)
words_path=local(CFG.get('alignment','words.json'))
words=json.loads(words_path.read_text(encoding='utf-8'))['words']
assert all(0<=w['s']<w['e']<=DURATION+.03 for w in words)
assert all(a['e']<=b['s']+.03 for a,b in zip(words,words[1:]))
current=0
for i,s in enumerate(shots):
    assert isinstance(s['n'],int) and s['n']>0
    assert local(s['file']).is_file(),s['file']
    if i:
        t=current/FPS
        assert any(a['w'].endswith(('.', '!', '?')) and a['e']<=t<=b['s'] for a,b in zip(words,words[1:])), ('Cắt trong câu',t)
    if not s.get('still'):
        src_probe=probe(local(s['file']))
        src_duration=float(src_probe['format']['duration'])
        assert s.get('ss',0)>=0 and s.get('ss',0)+s.get('srcdur',s['n']/FPS)<=src_duration+.04, ('Nguồn không đủ dài',s['file'])
    current+=s['n']
assert all(not (w['s']<HOOK_END<w['e']) for w in words), 'Hook cắt giữa từ.'
body_start=next(i for i,w in enumerate(words) if w['s']>=HOOK_END)
assert CFG['caption_ranges'][0][0]==body_start
assert CFG['caption_ranges'][-1][1]==len(words)
assert all(a[1]==b[0] for a,b in zip(CFG['caption_ranges'],CFG['caption_ranges'][1:]))
for first,last in CFG['caption_ranges']:
    assert first<last and not any(w['w'].endswith(('.', '!', '?')) for w in words[first:last-1])
music_cfg=CFG.get('music',{})
if 'path' not in music_cfg:
    raise SystemExit('Cần music.path trỏ tới bản nhạc chủ kênh đã cung cấp; nhạc ngoài không kèm gói public.')
music=local(music_cfg['path'])
assert music.is_file(),music
music_start=round(music_cfg.get('start_seconds',48.08)*48000)
assert music_cfg.get('gain_db',-20)==-20, 'Mẫu mặc định dùng gain -20 dB; chỉ đổi khi chủ kênh yêu cầu.'
music_duration=float(probe(music)['format']['duration'])
loop_end=music_cfg.get('loop_end_seconds')
assert music_start/48000<music_duration
if loop_end is None:
    assert music_start/48000+DURATION<=music_duration+.02, 'Chọn loop_end_seconds theo nhịp nếu video dài hơn nhạc còn lại.'
else:
    assert music_start/48000<float(loop_end)<=music_duration+.02
if '--check' in sys.argv:
    print('ĐẠT cấu hình: nguồn tồn tại, đủ thời lượng, cắt sau câu, phụ đề phủ đủ thân. Vẫn cần xem clip để kiểm điểm cắt sẵn.')
    raise SystemExit(0)

def run(args, name):
    with (ROOT/f'{name}.log').open('w') as log:
        r=subprocess.run([FF,'-hide_banner','-y',*args],stdout=log,stderr=log)
    if r.returncode:
        raise RuntimeError((ROOT/f'{name}.log').read_text()[-5000:])

# Preserve the supplied orange artwork and embedded logo exactly.
title=Image.new('RGBA',(W,H))
d=ImageDraw.Draw(title)
lines = CFG['title_lines']
font = ImageFont.truetype(FONT, CFG.get('title_size',66), index=CFG.get('title_font_index',4))
step = CFG.get('title_line_step',78)
bbs=[d.textbbox((73,i*step),s,font=font) for i,s in enumerate(lines)]
offset=round((1176+1528-(max(b[3] for b in bbs)-min(b[1] for b in bbs)))/2-min(b[1] for b in bbs))
for i,s in enumerate(lines): d.text((73,offset+i*step),s,font=font,fill='white')
assert title.getbbox()[0]>=72 and title.getbbox()[2]<=868
assert title.getbbox()[1]>=1176 and title.getbbox()[3]<=1528
title.save(ROOT/'title.png')
frame=Image.open(ASSETS/'khung-trong-co-logo-1080x1920.png').convert('RGBA')
frame.alpha_composite(title)
frame.save(ROOT/'hook-overlay.png')
logo=Image.open(ASSETS/'logo-chuyen-thuong-hieu.png').convert('RGBA').crop((0,230,1254,1140)).resize((190,138),Image.Resampling.LANCZOS)
overlay=Image.new('RGBA',(W,H)); overlay.alpha_composite(logo,(818,270))
overlay.save(ROOT/'body-overlay.png')
# Each caption uses forced word alignment against the approved audio.
# These phrase breaks keep model, feature and date names together.
phrase_ranges = CFG['caption_ranges']
cues = []
font_size = CFG.get('subtitle_size',41)
font_sub = ImageFont.truetype(FONT, font_size, index=CFG.get('subtitle_font_index',1))
for start, stop in phrase_ranges:
    ws = words[start:stop]
    phrase = ' '.join(word['w'].strip('.,') for word in ws)
    assert font_sub.getlength(phrase.upper())+12 <= 796, (phrase,font_sub.getlength(phrase.upper()))
    cues.append({'text':phrase.upper(),'words':ws,'t_in':max(HOOK_END,math.floor((ws[0]['s']-.02)*100)/100),
                 't_out':min(DURATION,ws[-1]['e']+.06)})
assert phrase_ranges[-1][-1] == len(words)
for a,b in zip(cues,cues[1:]): a['t_out']=min(a['t_out'],b['t_in'])

def ass_time(t):
    cs=round(t*100); return f'{cs//360000}:{cs//6000%60:02d}:{cs//100%60:02d}.{cs%100:02d}'
def srt_time(t):
    ms=round(t*1000); return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
header=f'''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{CFG.get('font_family','Helvetica Neue')},{font_size},&H00FFFFFF,&H00A8A8A8,&H00000000,&H90000000,-1,0,0,0,100,100,0,0,1,4,1.5,2,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
events=[]
for c in cues:
    cursor=round(c['t_in']*100); pieces=[]
    for i,w in enumerate(c['words']):
        start=round((w['s']-.02)*100); end=round((w['e']-.02)*100)
        gap=max(0,start-cursor)
        if i: pieces.append(r'{\k'+str(gap)+'} ')
        elif gap: pieces.append(r'{\k'+str(gap)+r'}\h')
        pieces.append(r'{\kf'+str(max(1,end-start))+'}'+w['w'].strip('.,').upper())
        cursor=end
    text=r'{\an2\pos(470,1480)}'+''.join(pieces)
    events.append(f"Dialogue: 0,{ass_time(c['t_in'])},{ass_time(c['t_out'])},Default,,0,0,0,,{text}")
(ROOT/'subs.ass').write_text(header+'\n'.join(events)+'\n')
(ROOT/'subs.srt').write_text('\n\n'.join(f"{i+1}\n{srt_time(c['t_in'])} --> {srt_time(c['t_out'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
# Captions retained verbatim from the approved edit.

# Editorial cuts are at frame-accurate pauses between spoken sentences.
# shots were validated before rendering
assert sum(s['n'] for s in shots) == TOTAL_FRAMES
current=0
for i,s in enumerate(shots):
    s['start']=current/FPS;current+=s['n'];s['end']=current/FPS
    s['path']=str(ROOT/f'shot-{i:02d}.mp4')
    dur=s['n']/FPS;source_dur=s.get('srcdur',dur)
    media_path = str(local(s['file']))
    if s.get('still'):
        args=['-loop','1','-i',media_path]
    else:
        args=['-ss',str(s.get('ss',0)),'-t',str(source_dur)]
        if s.get('av1'):
            args+=['-c:v','libaom-av1']
        args+=['-threads','4','-i',media_path]
    native_crop=f"crop={s['crop']}," if 'crop' in s else ''
    speed=dur/source_dur
    interpolation = s.get('interpolation', 'blend')
    # Set PTS to zero after interpolation so each scene has the planned frame count.
    timing=(f"setpts=(PTS-STARTPTS)*{speed},minterpolate=fps=30:mi_mode={interpolation},setpts=PTS-STARTPTS," if speed>1.05 else f'setpts=(PTS-STARTPTS)*{speed},')
    timing+=f"tpad=stop_mode=clone:stop_duration=0.40,fps=30,trim=end_frame={s['n']},"
    if s.get('kind')=='hook':
        args+=['-loop','1','-i',str(ROOT/'hook-overlay.png')]
        hook_x=s.get('x','(iw-1080)/2')
        hook_y=s.get('y','(ih-1015)/2')
        zoom_height=s.get('zoom_height',1016)
        filt=f"[0:v]{native_crop}scale=-2:{zoom_height},{timing}crop=1080:1015:x='{hook_x}':y='{hook_y}',pad=1080:1920:0:0:black,setsar=1[v];[v][1:v]overlay=0:0:shortest=1,format=yuv420p[out]"
    else:
        if s.get('still'):
            original_w,original_h=Image.open(media_path).size
        else:
            stream=next(v for v in probe(media_path)['streams'] if v['codec_type']=='video')
            original_w,original_h=stream['width'],stream['height']
        if 'crop' in s:
            original_w,original_h=map(int,s['crop'].split(':')[:2])
        natural_height=1080*original_h/original_w
        fg_height=s.get('height',round(natural_height/2)*2)
        assert abs(fg_height-natural_height)<=2, ('Chiều cao làm méo nguồn',s['name'],natural_height,fg_height)
        fg_y=s.get('fg_y',(1920-fg_height)//2)
        if s.get('still'):
            shot_frames = s['n']
            zoom = s.get('zoom', 0.05)
            foreground = (
                f"scale=2160:{2*fg_height},zoompan=z='1+{zoom}*on/{shot_frames - 1}':"
                f"x='(iw-iw/zoom)*0.46':y='(ih-ih/zoom)/2':"
                f"d={shot_frames}:s=1080x{fg_height}:fps=30,"
            )
        else:
            foreground = f"scale=1080:{fg_height},{timing}"
        filt=f"[0:v]{native_crop}{foreground}split=2[a][b];[a]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=14:2,eq=brightness=-0.19:saturation=0.65,scale=1080:1920[bg];[bg][b]overlay=0:{fg_y},setsar=1,format=yuv420p[out]"
    args+=['-filter_complex_threads','2','-filter_complex',filt,'-map','[out]','-an','-frames:v',str(s['n']),'-r','30','-c:v','libx264','-preset','veryfast','-crf','18','-threads','4','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',s['path']]
    run(args,f'shot-{i:02d}')
    with av.open(s['path']) as check:
        assert check.streams.video[0].frames==s['n'],('Incorrect scene length',s['name'],check.streams.video[0].frames,s['n'])
    print(f"Rendered {i+1}/{len(shots)} {s['name']}",flush=True)

(ROOT/'concat.txt').write_text('\n'.join("file '"+s['path']+"'" for s in shots)+'\n')
run(['-f','concat','-safe','0','-i',str(ROOT/'concat.txt'),'-c','copy',str(ROOT/'base.mp4')],'concat')
plan={'audio':str(ROOT/'voice-render.wav'),'alignment_path':str(words_path),'duration':DURATION,'hook_end':HOOK_END,'title_bounds':title.getbbox(),
      'shots':shots,'captions':cues,'font_size':font_size,'font':FONT,'font_index':CFG.get('subtitle_font_index',1),'video_path':str(local(CFG.get('output','video.mp4')))}
(ROOT/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
target=local(CFG.get('output','video.mp4'))
target.parent.mkdir(parents=True,exist_ok=True)
run(['-i',str(audio),'-ac','1','-ar','48000','-c:a','pcm_s16le',str(ROOT/'voice-render.wav')],'decode-voice')
samples=TOTAL_FRAMES*1600
run(['-i',str(ROOT/'voice-render.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-f','null','-'],'measure-voice')
measure=(ROOT/'measure-voice.log').read_text()
ld=json.loads(measure[measure.rindex('{'):measure.rindex('}')+1])
normalization=(f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={ld['input_i']}:measured_TP={ld['input_tp']}:"
 f"measured_LRA={ld['input_lra']}:measured_thresh={ld['input_thresh']}:offset={ld['target_offset']}:linear=true")
voice_filt=f'{normalization},aresample=48000,pan=stereo|FL=c0|FR=c0,apad,atrim=end_sample={samples}'
music_end=round(float(loop_end)*48000) if loop_end is not None else music_start+samples
music_filt=(f'aresample=48000,aformat=channel_layouts=stereo,atrim=start_sample={music_start}:'
            f'end_sample={music_end},asetpts=PTS-STARTPTS,')
if loop_end is not None:
    music_filt+=f'aloop=loop=-1:size={music_end-music_start},'
music_filt+=f'atrim=end_sample={samples},afade=t=in:d=0.012'
run(['-i',str(ROOT/'voice-render.wav'),'-af',voice_filt,'-c:a','pcm_f32le',str(ROOT/'voice-mix-reference.wav')],'voice-mix-reference')
run(['-i',str(music),'-af',music_filt,'-c:a','pcm_f32le',str(ROOT/'music-mix-reference.wav')],'music-mix-reference')
filt=(f"[0:v]setpts=N/(30*TB)[clock];[clock][1:v]overlay=0:0:enable='gte(n,{round(HOOK_END*FPS)})'[v];"
      f"[v]ass='{ROOT/'subs.ass'}'[out];[3:a]volume=-20dB[music];"
      "[2:a][music]amix=inputs=2:duration=first:normalize=0[mix]")
run(['-i',str(ROOT/'base.mp4'),'-loop','1','-i',str(ROOT/'body-overlay.png'),
     '-i',str(ROOT/'voice-mix-reference.wav'),'-i',str(ROOT/'music-mix-reference.wav'),
     '-filter_complex_threads','2','-filter_complex',filt,'-map','[out]','-map','[mix]',
     '-frames:v',str(TOTAL_FRAMES),'-t',str(DURATION),'-r','30','-c:v','libx264','-preset','fast','-crf','19','-threads','4',
     '-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',
     '-ar','48000','-c:a','aac','-b:a','256k','-movflags','+faststart',str(target)],'final-render')
print(target,flush=True)
