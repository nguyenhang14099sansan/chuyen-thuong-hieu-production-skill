"""Portable FFmpeg helpers; no account state or private machine paths."""
import json
import os
from pathlib import Path
import shutil
import subprocess


def ffmpeg_bin():
    value = os.environ.get('FFMPEG_BINARY') or shutil.which('ffmpeg')
    if not value:
        raise RuntimeError('Cần FFmpeg trên PATH hoặc biến FFMPEG_BINARY.')
    return str(value)


def probe(path):
    executable = os.environ.get('FFPROBE_BINARY') or shutil.which('ffprobe')
    if not executable:
        sibling = Path(ffmpeg_bin()).with_name('ffprobe')
        if sibling.is_file():
            executable = str(sibling)
    if not executable:
        raise RuntimeError('Cần ffprobe trên PATH hoặc biến FFPROBE_BINARY.')
    result = subprocess.run([executable, '-v', 'error', '-show_streams',
                             '-show_format', '-of', 'json', str(path)],
                            capture_output=True, check=True, text=True)
    return json.loads(result.stdout)
