from pathlib import Path
import json, subprocess, math, shutil
import av, numpy as np
from PIL import Image,ImageDraw,ImageFont

import sys
from common import ffmpeg_bin
R=Path(sys.argv[1]).resolve()
plan=json.loads((R/'plan.json').read_text())
video=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path(plan['video_path'])
ff=ffmpeg_bin()
N=round(plan['duration']*30); HOOK_N=round(plan['hook_end']*30)
c=av.open(str(video));v=c.streams.video[0];a=c.streams.audio[0]
report={'video':{'width':v.width,'height':v.height,'fps':str(v.average_rate),'codec':v.codec_context.name,
 'frames':v.frames,'duration':float(v.duration*v.time_base)},
 'audio':{'codec':a.codec_context.name,'rate':a.rate,'duration':float(a.duration*a.time_base)}}
assert (v.width,v.height,v.frames)==(1080,1920,N)
assert v.average_rate==30 and a.codec_context.name=='aac'

# Every planned picture change belongs to a pause after a complete sentence.
all_words=sorted([w for cue in plan['captions'] for w in cue['words']],key=lambda w:w['s'])
# Hook words are in alignment.json; retain them for sentence-boundary validation.
all_words=json.loads(Path(plan['alignment_path']).read_text())['words']
sentences=[];start=0
for i,w in enumerate(all_words):
    if w['w'].endswith(('.', '?', '!')):
        sentences.append({'start':all_words[start]['s'],'end':w['e'],'text':' '.join(x['w'] for x in all_words[start:i+1])})
        start=i+1
sentence_cuts=[]
for shot in plan['shots'][1:]:
    t=shot['start']
    matched=[(i,s,nxt) for i,(s,nxt) in enumerate(zip(sentences,sentences[1:])) if s['end']<=t<=nxt['start']]
    assert matched,('Picture changes while a sentence is being spoken',t)
    i,s,nxt=matched[0]
    sentence_cuts.append({'cut':t,'after_sentence':i+1,'sentence_end':s['end'],'next_sentence_start':nxt['start']})
report['sentence_pacing']={'continuous_shots':len(plan['shots']),'cuts_in_sentence_pauses':sentence_cuts}

r=subprocess.run([ff,'-hide_banner','-nostats','-i',str(video),'-af','loudnorm=print_format=json','-f','null','-'],capture_output=True,text=True).stderr
ld=json.loads(r[r.rindex('{'):r.rindex('}')+1]);report['loudness']=ld
assert -22<float(ld['input_i'])<-11 and float(ld['input_tp'])<-.5

# Measure subtitle geometry and the white karaoke sweep from the same libass
# renderer used in the exported file. Source audio alignment is a separate input.
p=subprocess.Popen([ff,'-v','error','-f','lavfi','-i',f"color=black:s=1080x1920:r=30:d={plan['duration']+.01}",
 '-vf',f"ass='{R/'subs.ass'}',crop=1080:160:0:1360,format=gray",'-frames:v',str(N),'-f','rawvideo','-'],stdout=subprocess.PIPE)
rows=[];masks=[];n=1080*160
while True:
    b=p.stdout.read(n)
    if len(b)!=n:break
    im=np.frombuffer(b,np.uint8).reshape(160,1080)
    masks.append(np.packbits(im>145));ys,xs=np.where(im>24); wy,wx=np.where(im>238)
    rows.append({'bbox':(int(xs.min()),int(ys.min()+1360),int(xs.max()+1),int(ys.max()+1361)) if len(xs) else None,
                 'white_right':int(wx.max()) if len(wx) else -1})
assert p.wait()==0 and len(rows)==N
assert all(r['bbox'] is None for r in rows[:HOOK_N])
bad=[]
for i,r in enumerate(rows):
    if r['bbox']:
        x0,y0,x1,y1=r['bbox']
        # Include the four pixel black outline and its shadow in the safe box.
        if not (x0-5>=72 and x1+5<=868 and y0-5>=1398 and y1+7<=1508):bad.append((i,r['bbox']))
assert not bad,bad[:5]
report['subtitle_bbox_union']=[min(r['bbox'][0]-5 for r in rows if r['bbox']),min(r['bbox'][1]-5 for r in rows if r['bbox']),max(r['bbox'][2]+5 for r in rows if r['bbox']),max(r['bbox'][3]+7 for r in rows if r['bbox'])]

font=ImageFont.truetype(plan['font'],plan['font_size'],index=plan['font_index'])
errs=[];missing=[]
for cue in plan['captions']:
    lo=math.ceil(cue['t_in']*30-1e-5);hi=min(N,math.ceil(cue['t_out']*30))
    rs=[r for r in rows[lo:hi] if r['bbox']]
    assert rs,cue['text']
    x0=int(np.median([r['bbox'][0] for r in rs]));x1=int(np.median([r['bbox'][2] for r in rs]))
    ws=cue['words']; text=' '.join(w['w'].strip('.,').upper() for w in ws)
    scale=(x1-x0)/font.getlength(text)
    for k,w in enumerate(ws):
        mid=round((w['s']+w['e'])/2*30)
        if not rows[mid]['bbox']:missing.append(w)
        if k==0:
            onset=next(i for i in range(lo,hi) if rows[i]['bbox'])/30
        else:
            # Pixel threshold just inside the glyph area, allowing anti-aliasing.
            x=x0+font.getlength(' '.join(z['w'].strip('.,').upper() for z in ws[:k])+' ')*scale+2
            hits=[i for i in range(lo,hi) if rows[i]['white_right']>=x]
            if not hits:continue
            onset=hits[0]/30
        errs.append({'word':w['w'],'reference':w['s'],'rendered':onset,'error_ms':round((onset-w['s'])*1000,1)})
assert not missing
report['karaoke_measured_words']=len(errs)
report['karaoke_largest_errors']=sorted(errs,key=lambda e:abs(e['error_ms']),reverse=True)[:12]
report['karaoke_mean_error_ms']=round(sum(e['error_ms'] for e in errs)/len(errs),1)

# Actual exported frames, including the frames immediately around all cuts.
frames={}; actual_rows=[]; hook_title_boxes=[]; picture_change_candidates=[];prev_picture=None;wanted={min(N-1,k) for k in [15,60,HOOK_N-1,HOOK_N,HOOK_N+3,150,540,N-30,N-1]}
for s in plan['shots']:
    k=round(s['start']*30)
    wanted.update([max(0,k-1),k,min(N-1,k+1)])
wanted.update(range(15,N,30))
for i,f in enumerate(c.decode(v)):
    rgb=f.to_ndarray(format='rgb24')
    if i in wanted:frames[i]=Image.fromarray(rgb)
    # Scan the actual picture, excluding the logo and narration captions.
    picture=rgb[250:850] if i<HOOK_N else rgb[790:1160]
    picture=np.asarray(Image.fromarray(picture).resize((160,80)),dtype=np.float32)
    if prev_picture is not None:
        delta=float(np.abs(picture-prev_picture).mean()/255)
        if delta>.09:picture_change_candidates.append({'frame':i,'time':i/30,'pixel_change':round(delta,4)})
    prev_picture=picture
    if i<HOOK_N:
        title_band=rgb[1176:1528]
        title_mask=(title_band.min(2)>230)&((title_band.max(2).astype(int)-title_band.min(2).astype(int))<18)
        ty,tx=np.where(title_mask)
        assert len(tx)>100
        box=[int(tx.min()),int(ty.min()+1176),int(tx.max()+1),int(ty.max()+1177)]
        assert box[0]>=72 and box[2]<=868 and box[1]>=1176 and box[3]<=1528,box
        hook_title_boxes.append(box)
    band=rgb[1360:1520]
    mask=np.unpackbits(masks[i]).reshape(160,1080).astype(bool)
    white=(band.min(2)>230)&((band.max(2).astype(int)-band.min(2).astype(int))<32)&mask
    xs=np.where(white.sum(0)>0)[0]
    actual_rows.append(int(xs.max()) if len(xs) else -1)

assert HOOK_N-1 in frames and HOOK_N in frames
report['actual_hook_title_bounds']=[min(b[0] for b in hook_title_boxes),min(b[1] for b in hook_title_boxes),max(b[2] for b in hook_title_boxes),max(b[3] for b in hook_title_boxes)]
report['actual_picture_change_candidates']=picture_change_candidates
report['unplanned_picture_change_candidates']=[x for x in picture_change_candidates if min(abs(x['time']-s['start']) for s in plan['shots'][1:])>.10]
# Orange panel occupies its original bottom half through frame 119 only.
def orange_pixels(im):
    ar=np.asarray(im)[1150:1550,20:1050,:].astype(int)
    return float(((ar[:,:,0]>110)&(ar[:,:,0]>ar[:,:,1]*1.8)&(ar[:,:,1]>15)&(ar[:,:,1]<110)).mean())
assert orange_pixels(frames[HOOK_N-1])>.75
assert orange_pixels(frames[HOOK_N])<.1
report['hook_cutoff_seconds']=plan['hook_end']
report['title_bbox']=plan['title_bounds']

# Measure the white sweep in the actual compressed video, restricted to the
# expected glyph interiors so the moving footage cannot be mistaken for letters.
actual_errors=[]
for cue in plan['captions']:
    lo=math.ceil(cue['t_in']*30-1e-5);hi=min(N,math.ceil(cue['t_out']*30))
    rs=[r for r in rows[lo:hi] if r['bbox']]
    x0=int(np.median([r['bbox'][0] for r in rs]));x1=int(np.median([r['bbox'][2] for r in rs]))
    ws=cue['words'];scale=(x1-x0)/font.getlength(' '.join(w['w'].strip('.,').upper() for w in ws))
    for k,w in enumerate(ws):
        if k==0:
            hits=[i for i in range(lo,hi) if actual_rows[i]>=x0]
        else:
            x=x0+font.getlength(' '.join(z['w'].strip('.,').upper() for z in ws[:k])+' ')*scale+2
            hits=[i for i in range(lo,hi) if actual_rows[i]>=x]
        assert hits, w
        onset=hits[0]/30
        actual_errors.append({'word':w['w'],'reference':w['s'],'rendered':onset,'error_ms':round((onset-w['s'])*1000,1)})
report['actual_export_karaoke_measured_words']=len(actual_errors)
report['actual_export_karaoke_largest_errors']=sorted(actual_errors,key=lambda e:abs(e['error_ms']),reverse=True)[:12]
assert max(abs(e['error_ms']) for e in actual_errors)<=1000*2/30+0.1,report['actual_export_karaoke_largest_errors']

# Compare approved voice to the AAC export without assuming a renderer delay.
def pcm(path):
    b=subprocess.run([ff,'-v','error','-i',str(path),'-ac','1','-ar','16000','-f','f32le','-'],capture_output=True,check=True).stdout
    return np.frombuffer(b,np.float32)
src=pcm(R/'voice-mix-reference.wav');dst=pcm(video)
music_ref=pcm(R/'music-mix-reference.wav')
ns=min(len(src),len(dst),len(music_ref))
gains=np.linalg.lstsq(np.column_stack((src[:ns],music_ref[:ns])),dst[:ns],rcond=None)[0]
assert abs(20*np.log10(gains[0]))<.1 and abs(20*np.log10(gains[1])+20)<.25,gains
assert np.min([np.sqrt(np.mean(w*w)) for w in (music_ref[:8000],music_ref[-8000:])])>.02
report['mix_gains_db']=[float(x) for x in 20*np.log10(gains)]
dst=dst[:ns]-music_ref[:ns]*gains[1]
scores=[]
for lag in range(-160,161):
    x=src[max(0,-lag):min(len(src),len(dst)-lag)]
    y=dst[max(0,lag):min(len(dst),len(src)+lag)]
    scores.append((float(np.dot(x,y)/(np.linalg.norm(x)*np.linalg.norm(y)+1e-9)),lag))
corr,lag=max(scores)
report['voice_waveform_correlation']=round(corr,5)
report['voice_offset_ms']=lag/16
report['approved_voice_seconds']=len(src)/16000
assert corr>.98 and abs(lag)<=32

sampled=sorted(k for k in frames if k%30==15)
sheet=Image.new('RGB',(8*216,math.ceil(len(sampled)/8)*409),(20,20,20));d=ImageDraw.Draw(sheet)
for i,k in enumerate(sampled):
    im=frames[k].resize((216,384));x=i%8*216;y=i//8*409
    sheet.paste(im,(x,y+25));d.text((x+6,y+5),f'{k/30:.2f}s',fill='white')
sheet.save(R/'qa-every-second.jpg')
keys=[min(N-1,k) for k in [15,60,HOOK_N-1,HOOK_N,HOOK_N+3,150,540,N-30,N-1]]
sheet=Image.new('RGB',(3*360,3*665),(20,20,20));d=ImageDraw.Draw(sheet)
for i,k in enumerate(keys):
    im=frames[k].resize((360,640));x=i%3*360;y=i//3*665
    sheet.paste(im,(x,y+25));d.text((x+7,y+5),f'frame {k} / {k/30:.3f}s',fill='white')
sheet.save(R/'qa-boundary-and-layout.jpg')
for k in [min(N-1,k) for k in [15,HOOK_N-1,HOOK_N,150,540,N-30,N-1]]:frames[k].save(R/f'final-{k}.jpg')
(R/'qa-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
